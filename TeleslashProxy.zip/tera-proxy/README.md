User-friendly branch of tera-proxy.

* Set your region in bin/config.json
* Mods go in bin/node_modules/
